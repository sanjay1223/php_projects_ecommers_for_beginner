<div class="container-fluid bg-dark">
    <p class="text-white text-center py-3">
        Copyright &copy; <?php echo date("Y"); ?> | Our Project Development
    </p>
</div>