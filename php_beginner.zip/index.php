<?php 
session_start();
require "inc/process.php"; 
require "inc/header.php"; 
require "body.php";
require "inc/footer.php";

?>